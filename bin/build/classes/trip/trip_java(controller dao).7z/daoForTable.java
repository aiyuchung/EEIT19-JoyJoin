package trip;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import com.lcp.bean.TripBean;
import com.lcp.bean.TripTypeBean;

public class daoForTable {
	
	private static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=trip";
	private static final String USER = "sa";
	private static final String PASSWORD = "passw0rd";

		
	
	public void dao_update(String[] UpdateOne) {
	Connection conn = null;
	String SQL = "UPDATE trip SET trip_class_no=?,trip_type_no=?,trip_name=?,trip_location=?,"
			+ "trip_prov=?,trip_date=?,trip_fee=? WHERE trip_no=?";
	
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			
			PreparedStatement pstmt = conn.prepareStatement(SQL);
//			System.out.println(UpdateOne[0]);
//			System.out.println(UpdateOne[1]);//ename
//			System.out.println(UpdateOne[2]);//hiredate
//			System.out.println(UpdateOne[3]);//salary
//			System.out.println(UpdateOne[4]);//deptno
//			System.out.println(UpdateOne[5]);//title
//						
//			pstmt.setDouble(6,Integer.parseInt(UpdateOne[0]));//UpdateOne[0] = empno
//			pstmt.setString(1,UpdateOne[1]);
//			pstmt.setDate(2,java.sql.Date.valueOf(UpdateOne[2]));
//			pstmt.setInt(3,Integer.parseInt(UpdateOne[3]));
//			pstmt.setDouble(4,Integer.parseInt(UpdateOne[4]));
//			pstmt.setString(5,UpdateOne[5]);
			
			pstmt.setString(8,UpdateOne[0]);
			for (int i = 1 ; i < 8 ; i++) {
				pstmt.setString(i,UpdateOne[i]);
			}
			pstmt.execute();
			pstmt.close();
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  catch (SQLException e) {
//			if (e.getErrorCode() == 208){
			System.out.println("Message : " + e.getMessage());
			System.out.println("Please check the mentioned object name.");
//			}
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	
	public TripBean dao_selectOne(String tripNo) {
		Connection conn = null;	
		String SQL = "SELECT * FROM trip " + 
				"INNER JOIN trip_class AS c ON trip.trip_class_no = c.trip_class_no\r\n" + 
				"INNER JOIN trip_type AS t ON trip.trip_type_no = t.trip_type_no \r\n" + 
				"WHERE trip_no=?	";
		TripBean trip = null;
		try {
			
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			
			PreparedStatement stmt = conn.prepareStatement(SQL);
			stmt.setString(1, tripNo);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				trip = new TripBean();
				trip.setTripNo(rs.getString("trip_no"));
				trip.setTripClass(rs.getString("trip_class_name"));
				trip.setTripClassNo(rs.getString("trip_class_no"));
				trip.setTripType(rs.getString("trip_type_name"));
				trip.setTripTypeNo(rs.getString("trip_type_no"));
				trip.setTripName(rs.getString("trip_name"));
				trip.setTripLocation(rs.getString("trip_location"));
				trip.setTripProv(rs.getString("trip_prov"));
				trip.setTripDate(rs.getString("trip_date"));
				trip.setTripFee(rs.getString("trip_fee"));

			}
			stmt.close();
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  catch (SQLException e) {
			if (e.getErrorCode() == 208){
			System.out.println("Message : " + e.getMessage());
			System.out.println("Please check the mentioned object name.");
			}
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return trip;
	}
	
	
	public void dao_insert(String[] InsertOne) {
		Connection conn = null;
		String SQL = "INSERT INTO trip (trip_class_no,trip_type_no,trip_name,trip_location,trip_prov,trip_date,trip_fee) VALUES (?,?,?,?,?,?,?)";
		
			try {
				Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
				
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				for (int i = 1; i < 8; i++) {
					pstmt.setString(i,InsertOne[i-1]);
				}
				pstmt.execute();
				pstmt.close();
			}  catch (ClassNotFoundException e) {
				e.printStackTrace();
			}  catch (SQLException e) {
				if (e.getErrorCode() == 208){
				System.out.println("Message : " + e.getMessage());
				System.out.println("Please check the mentioned object name.");
				}
			} finally {
				if (conn != null)
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		}
	
	
	public List<TripBean> dao_selectAll() {
		Connection conn = null;
		String SQL = "SELECT * FROM trip " +
				"INNER JOIN trip_class AS c ON trip.trip_class_no = c.trip_class_no\r\n" + 
				"INNER JOIN trip_type AS t ON trip.trip_type_no = t.trip_type_no \r\n"  ;
		List<TripBean> emps = new ArrayList<>();
		//System.out.println("dao value in method");
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			
			PreparedStatement stmt = conn.prepareStatement(SQL);
			
			ResultSet rs = stmt.executeQuery();
			
			TripBean emp = null;			
			
			while (rs.next()) {
				emp = new TripBean();
				emp.setTripNo(rs.getString("trip_no"));
				emp.setTripClass(rs.getString("trip_class_name"));
				emp.setTripType(rs.getString("trip_type_name"));
				emp.setTripName(rs.getString("trip_name"));
				emp.setTripProv(rs.getString("trip_prov"));
				emp.setTripDate(rs.getString("trip_date"));
				emps.add(emp);
			}
			System.out.println("dao value:"+rs.getString("tripNo"));
			stmt.close();
			
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  catch (SQLException e) {
//			if (e.getErrorCode() == 208){
//			System.out.println("Message : " + e.getMessage());
//			System.out.println("Please check the mentioned object name.");
//			}
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return emps;
	}
	
	/**
	 * 查詢type list
	 * */
	public List<TripTypeBean> findTypeList(String classNo) {
		Connection conn = null;
		String SQL = "SELECT * FROM trip_type t  " + 
				"INNER JOIN  [dbo].[trip_class_type] ct " + 
				"ON t.trip_type_no = ct.trip_type_no " + 
				"where ct.trip_class_no = ?;";
		List<TripTypeBean> tripTypeList = new ArrayList<>();
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			
			PreparedStatement stmt = conn.prepareStatement(SQL);
			stmt.setString(1, classNo);
			ResultSet rs = stmt.executeQuery();
			
			TripTypeBean tripType = null;			
			
			while (rs.next()) {
				tripType = new TripTypeBean();
				tripType.setTripTypeNo(rs.getString("trip_type_no"));
				tripType.setTripTypeName(rs.getString("trip_type_name"));
				tripTypeList.add(tripType);
			}
			stmt.close();
			
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  catch (SQLException e) {
			if (e.getErrorCode() == 208){
			System.out.println("Message : " + e.getMessage());
			System.out.println("Please check the mentioned object name.");
			}
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return tripTypeList;
		
	}
	
	
	public void dao_delete(String tripNo) {
		Connection conn = null;	
		String SQL = "DELETE FROM trip WHERE trip_no=?";
		try {
			
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			
			PreparedStatement stmt = conn.prepareStatement(SQL);
			stmt.setString(1, tripNo);				
			stmt.execute();
			stmt.close();
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  catch (SQLException e) {
			if (e.getErrorCode() == 208){
			System.out.println("Message : " + e.getMessage());
			System.out.println("Please check the mentioned object name.");
			}
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	
}
	
