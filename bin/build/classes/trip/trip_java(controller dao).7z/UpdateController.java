package trip;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lcp.bean.TripBean;


@WebServlet("/trip/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String tripNo = request.getParameter("tripNo");
		String[] UpdateOne = new String[8];
		UpdateOne[0] = request.getParameter("tripNo");
		UpdateOne[1] = request.getParameter("tripClass");
		UpdateOne[2]  = request.getParameter("tripType");
		UpdateOne[3]  = request.getParameter("tripName");
		UpdateOne[4]  = request.getParameter("tripLocation");
		UpdateOne[5]  = request.getParameter("tripProv");
		UpdateOne[6]  = request.getParameter("tripDate");
		UpdateOne[7]  = request.getParameter("tripFee");
		System.out.println("controller array:" + UpdateOne[0]);
		daoForTable dao = new daoForTable();
		dao.dao_update(UpdateOne);
		TripBean OneTrip= dao.dao_selectOne(tripNo);
		request.setAttribute("trip", OneTrip);
		
		request.getRequestDispatcher("/trip/Update_OK.jsp").forward(request, response);
		
	}

}
