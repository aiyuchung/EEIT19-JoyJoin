package trip;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lcp.bean.TripBean;


@WebServlet("/trip/InsertController")
public class InsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String[] InsertOne = new String[7];
		request.setCharacterEncoding("UTF-8");	
		InsertOne[0] = request.getParameter("tripClass");
		InsertOne[1]  = request.getParameter("tripType");
		InsertOne[2]  = request.getParameter("tripName");
		InsertOne[3]  = request.getParameter("tripLocation");
		InsertOne[4]  = request.getParameter("tripProv");
		InsertOne[5]  = request.getParameter("tripDate");
		InsertOne[6]  = request.getParameter("tripFee");
		
		
		
		daoForTable dao = new daoForTable();
		dao.dao_insert(InsertOne);
		
		List<TripBean> AllTrip = dao.dao_selectAll();
		request.setAttribute("trips", AllTrip);
		request.getRequestDispatcher("/trip/selectTrip.jsp").forward(request, response);
	
	}

}
