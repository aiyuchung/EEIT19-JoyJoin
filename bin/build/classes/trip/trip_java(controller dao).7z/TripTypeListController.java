package trip;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.lcp.bean.TripTypeBean;

@WebServlet("/trip/typeList")
public class TripTypeListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

//	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//	 
//            throws ServletException, IOException {
// 
//        response.setContentType("text/html;charset=UTF-8");
// 
//        //���oAjax�ǤJ���Ѽ�
//        daoForTable dao = new daoForTable();
//		String classNo = request.getParameter("classNo");
//		List<TripTypeBean> tripTypeList = dao.findTypeList(classNo);
////		request.setAttribute("tripTypeList", tripTypeList);
////		request.getRequestDispatcher("/trip/selectTrip.jsp").forward(request, response);
//		
////		JSONObject responseJSONObject = new JSONObject(userInfoMap);
//		 
//        PrintWriter out = response.getWriter();
//        out.println(tripTypeList);
//        
// 
//    }
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		daoForTable dao = new daoForTable();
//		String classNo = request.getParameter("classNo");
//		List<TripTypeBean> tripTypeList = dao.findTypeList(classNo);
//        PrintWriter out = response.getWriter();
//        out.println(tripTypeList);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		daoForTable dao = new daoForTable();
		String classNo = request.getParameter("classNo");
		response.setContentType("text/html;charset=UTF-8");
		List<TripTypeBean> tripTypeList = dao.findTypeList(classNo);
//        PrintWriter out = response.getWriter();
        
        Gson gson = new Gson();
		String outputStr = gson.toJson(tripTypeList);
		System.out.println(outputStr);
		response.getWriter().write(outputStr);
     
	}

}
