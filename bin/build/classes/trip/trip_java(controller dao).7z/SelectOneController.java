package trip;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lcp.bean.TripBean;


@WebServlet("/trip/SelectOneController")
public class SelectOneController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String tripNo = request.getParameter("tripNo");
		request.setCharacterEncoding("UTF-8");
		daoForTable dao = new daoForTable();
		TripBean OneTrip = dao.dao_selectOne(tripNo);
		request.setAttribute("trip", OneTrip);
		request.getRequestDispatcher("/trip/OneTrip.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		doGet(request, response);
	}

}
